# Redux คืออะไร? + เริ่มต้นเรียนรู้ Redux ร่วมกับ React กันดีกว่า

[อ่านบทความ](https://devahoy.com/blog/2018/07/introduction-to-redux/)
