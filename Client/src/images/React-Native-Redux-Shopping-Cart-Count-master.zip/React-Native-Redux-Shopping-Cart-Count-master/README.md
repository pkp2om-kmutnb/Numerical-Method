# React-Native-Redux-Shopping-Cart-Count
Keep a track of items in your shopping cart using react native and redux

# Project files for Youtube Tutorial
- https://www.youtube.com/watch?v=R39sa1RQyI8&t=6s

# Demo 

<a href="https://imgflip.com/gif/2l7chd"><img src="https://i.imgflip.com/2l7chd.gif" title="made at imgflip.com"/></a>
