export const electronics = [
    {
        id: 1,
        name: 'Fifa 19',
        price: 49.99
    },
    {
        id: 2,
        name: 'Amazon Echo',
        price: 199
    },
    {
        id: 3,
        name: 'Bose QC 35 Headphones',
        price: 300
    }
]

export const books = [
    {
        id: 4,
        name: 'How to Kill a Mocking Bird',
        price: 10
    },
    {
        id: 5,
        name: 'War of Art',
        price: 7
    },
    {
        id: 6,
        name: 'Relentless',
        price: 5.99
    }
]

